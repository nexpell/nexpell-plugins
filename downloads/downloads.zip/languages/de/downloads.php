<?php

$language_array = Array(

    'title' => 'Downloads',

    'downloads' => 'Downloads',
    'upload_file' => 'Datei hochladen',
    'title' => 'Downloads',
    'description' => 'Beschreibung',
    'category' => 'Kategorie',
    'save' => 'Speichern',
    'select_category' => 'Kategorie auswählen',
    'access_roles' => 'Zugriffsrollen',
    'upload' => 'Hochladen',
    'admin_area' => 'Adminbereich',
    'download_count' => 'Zugriffe',
);
