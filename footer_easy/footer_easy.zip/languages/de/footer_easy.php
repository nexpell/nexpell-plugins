<?php

$language_array = array(

   'title' => 'Footer Links',
    'link' => 'Link-Adresse',
    'name' => 'Link-Name',
    'new_tab' => 'In neuem Tab öffnen',
    'save' => 'Speichern',
    'success' => 'Footer-Daten wurden erfolgreich gespeichert.',
    'breadcrumb_edit' => 'Bearbeiten',
     
    );

