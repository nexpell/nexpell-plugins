<?php

$language_array = array(

    'title' => 'Benutzer-Login-Übersicht',
    'lastlogin_activity_control' => 'Letzter Login & Aktivitätsstatus',
    'lastlogin_id' => 'ID',
    'lastlogin_member' => 'Benutzername',
    'lastlogin_lastlogin' => 'Letzter Login',
    'lastlogin_in_days' => 'Tage seit Login',
    'lastlogin_activity' => 'Aktiv',
    'lastlogin_squad' => 'Squad',
    'lastlogin_filter_all_activity' => 'Alle (aktiv + inaktiv)',
    'lastlogin_activ' => 'Aktiv',
    'lastlogin_inactiv' => 'Inaktiv',
    'lastlogin_filter_all_squads' => 'Alle Squads',
    'lastlogin_search_username' => 'Benutzername suchen',
    'lastlogin_submit' => 'Filtern',
    'lastlogin_day' => 'Tag',
    'lastlogin_clock' => 'Uhrzeit',
    'lastlogin_today' => 'Heute',
    'lastlogin_yesterday' => 'Gestern',
    'lastlogin_before' => 'Vor',
    'lastlogin_days' => 'Tagen',

);

