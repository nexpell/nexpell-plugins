<?php

$language_array = array(

    'lastlogin_activity_control' => 'Controllo delle attività dei membri',
  'lastlogin_number'           => 'Numbero',
  'lastlogin_id'               => 'ID',
  'lastlogin_member'           => 'Membro',
  'lastlogin_lastlogin'        => 'Ultimo online',
  'lastlogin_in_days'          => 'In giorni',
  'lastlogin_activity'         => 'Actività',
  'lastlogin_today'            => 'Oggi',
  'lastlogin_yesterday'        => 'Ieri',
  'lastlogin_activ'            => 'Attivo',
  'lastlogin_inactiv'          => 'Inattivo',
  'lastlogin_day'              => 'Giono',
  'lastlogin_clock'            => 'Ora',
  'lastlogin_select_members'   => 'Seleziona Memberi',
  'lastlogin_all_squad_users'  => 'Tutti i Membri del Team',
  'lastlogin_all_users'        => 'Tutti gli utenti registrati',
  'lastlogin_submit'           => 'Invia',
  'lastlogin_before'           => 'Prima',
  'lastlogin_days'             => 'Giorni',
  'lastlogin_squad'            => 'Team',
  'lastlogin_title'                      => 'Ultimo Login'
);

