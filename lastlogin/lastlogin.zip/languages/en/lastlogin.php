<?php

$language_array = array(

    'lastlogin_activity_control'  => 'Member activity control',
  'lastlogin_number'            => 'Number',
  'lastlogin_id'                => 'ID',
  'lastlogin_member'            => 'Member',
  'lastlogin_lastlogin'         => 'Last online',
  'lastlogin_in_days'           => 'In days',
  'lastlogin_activity'          => 'Activity',
  'lastlogin_today'             => 'Today',
  'lastlogin_yesterday'         => 'Yesterday',
  'lastlogin_activ'             => 'Activ',
  'lastlogin_inactiv'           => 'Inactiv',
  'lastlogin_day'               => 'Day',
  'lastlogin_clock'             => 'Time',
  'lastlogin_select_members'    => 'Select Members',
  'lastlogin_all_squad_users'   => 'All Team Members',
  'lastlogin_all_users'         => 'All registered Users',
  'lastlogin_submit'            => 'Submit',
  'lastlogin_before'            => 'Before',
  'lastlogin_days'              => 'Days',
  'lastlogin_squad'             => 'Squad',
  'lastlogin_title'                       => 'Last Login'
);

